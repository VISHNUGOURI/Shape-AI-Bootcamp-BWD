import React from "react";
function Note(){
  return(
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This was an amazing Boot camp .We covered every thing from scratch icluding Javascript,React.js,HTML.
        </p>
    </div>
  )
}
export default Note;